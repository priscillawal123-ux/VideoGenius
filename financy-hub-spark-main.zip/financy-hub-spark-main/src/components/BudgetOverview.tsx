import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";

const budgets = [
  { category: "Alimentação", spent: 1200, total: 1500, color: "bg-primary" },
  { category: "Transporte", spent: 800, total: 1000, color: "bg-accent" },
  { category: "Lazer", spent: 600, total: 800, color: "bg-warning" },
  { category: "Outros", spent: 400, total: 700, color: "bg-success" },
];

export const BudgetOverview = () => {
  return (
    <Card className="shadow-md">
      <CardHeader>
        <CardTitle>Orçamento Mensal</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          {budgets.map((budget) => {
            const percentage = (budget.spent / budget.total) * 100;
            const isOverBudget = percentage > 90;
            
            return (
              <div key={budget.category} className="space-y-2">
                <div className="flex justify-between items-center">
                  <span className="font-medium text-foreground">{budget.category}</span>
                  <span className="text-sm text-muted-foreground">
                    R$ {budget.spent} / R$ {budget.total}
                  </span>
                </div>
                <Progress 
                  value={percentage} 
                  className="h-2"
                  indicatorClassName={isOverBudget ? "bg-destructive" : budget.color}
                />
                <p className="text-xs text-muted-foreground">
                  {percentage.toFixed(0)}% utilizado
                </p>
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
};
