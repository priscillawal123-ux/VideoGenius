import { Home, BarChart3, CreditCard, Settings, TrendingUp, Wallet } from "lucide-react";
import { NavLink } from "react-router-dom";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  useSidebar,
} from "@/components/ui/sidebar";

const menuItems = [
  { title: "Dashboard", url: "/", icon: Home },
  { title: "Transações", url: "/transactions", icon: CreditCard },
  { title: "Análises", url: "/analytics", icon: BarChart3 },
  { title: "Investimentos", url: "/investments", icon: TrendingUp },
  { title: "Carteiras", url: "/wallets", icon: Wallet },
  { title: "Configurações", url: "/settings", icon: Settings },
];

export function DashboardSidebar() {
  const { open } = useSidebar();

  return (
    <Sidebar collapsible="icon" className="border-r border-sidebar-border">
      <SidebarContent>
        <div className="px-4 py-6">
          <h2 className={`text-xl font-bold text-sidebar-foreground transition-opacity ${!open ? 'opacity-0' : 'opacity-100'}`}>
            FinDash
          </h2>
        </div>
        
        <SidebarGroup>
          <SidebarGroupLabel className={!open ? 'opacity-0' : 'opacity-100'}>Menu</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {menuItems.map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton asChild>
                    <NavLink
                      to={item.url}
                      className={({ isActive }) =>
                        isActive
                          ? "bg-sidebar-accent text-sidebar-accent-foreground"
                          : "hover:bg-sidebar-accent/50"
                      }
                    >
                      <item.icon className="h-5 w-5" />
                      {open && <span>{item.title}</span>}
                    </NavLink>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
    </Sidebar>
  );
}
