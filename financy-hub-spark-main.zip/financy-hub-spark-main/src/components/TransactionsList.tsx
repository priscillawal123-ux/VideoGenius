import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowUpRight, ArrowDownRight, ShoppingBag, Home, Car, Coffee } from "lucide-react";
import { cn } from "@/lib/utils";

const transactions = [
  { id: 1, name: "Supermercado", amount: -245.50, date: "Hoje", type: "expense", icon: ShoppingBag },
  { id: 2, name: "Salário", amount: 5000.00, date: "Hoje", type: "income", icon: ArrowDownRight },
  { id: 3, name: "Aluguel", amount: -1500.00, date: "Ontem", type: "expense", icon: Home },
  { id: 4, name: "Uber", amount: -32.80, date: "Ontem", type: "expense", icon: Car },
  { id: 5, name: "Café", amount: -18.50, date: "2 dias atrás", type: "expense", icon: Coffee },
];

export const TransactionsList = () => {
  return (
    <Card className="shadow-md">
      <CardHeader>
        <CardTitle>Transações Recentes</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {transactions.map((transaction) => {
            const Icon = transaction.icon;
            const isIncome = transaction.type === "income";
            
            return (
              <div key={transaction.id} className="flex items-center justify-between p-3 rounded-lg hover:bg-muted/50 transition-colors">
                <div className="flex items-center gap-3">
                  <div className={cn(
                    "p-2 rounded-lg",
                    isIncome ? "bg-success-light" : "bg-muted"
                  )}>
                    <Icon className={cn(
                      "h-5 w-5",
                      isIncome ? "text-success" : "text-foreground"
                    )} />
                  </div>
                  <div>
                    <p className="font-medium text-foreground">{transaction.name}</p>
                    <p className="text-sm text-muted-foreground">{transaction.date}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <span className={cn(
                    "font-semibold text-lg",
                    isIncome ? "text-success" : "text-foreground"
                  )}>
                    {isIncome ? "+" : "-"}R$ {Math.abs(transaction.amount).toFixed(2)}
                  </span>
                  {isIncome ? (
                    <ArrowDownRight className="h-5 w-5 text-success" />
                  ) : (
                    <ArrowUpRight className="h-5 w-5 text-destructive" />
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
};
