import { DashboardLayout } from "@/components/DashboardLayout";
import { MetricCard } from "@/components/MetricCard";
import { SpendingChart } from "@/components/SpendingChart";
import { CategoryChart } from "@/components/CategoryChart";
import { TransactionsList } from "@/components/TransactionsList";
import { BudgetOverview } from "@/components/BudgetOverview";
import { AIInsights } from "@/components/AIInsights";
import { Wallet, TrendingUp, TrendingDown, PiggyBank } from "lucide-react";

const Index = () => {
  // Dados financeiros para contexto da IA
  const financialData = {
    balance: 12450,
    income: 8320,
    expenses: 4580,
    savings: 3740,
    recentTransactions: [
      { name: "Supermercado", amount: -245.50, type: "expense" },
      { name: "Salário", amount: 5000.00, type: "income" },
      { name: "Aluguel", amount: -1500.00, type: "expense" },
      { name: "Uber", amount: -32.80, type: "expense" },
      { name: "Café", amount: -18.50, type: "expense" },
    ]
  };

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-foreground mb-2">Dashboard Financeiro</h1>
          <p className="text-muted-foreground">Bem-vindo de volta! Aqui está um resumo das suas finanças.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <MetricCard
            title="Saldo Total"
            value="R$ 12.450,00"
            change="+2.5% este mês"
            changeType="positive"
            icon={Wallet}
            iconClassName="bg-gradient-primary text-primary-foreground"
          />
          <MetricCard
            title="Receitas"
            value="R$ 8.320,00"
            change="+5.2% este mês"
            changeType="positive"
            icon={TrendingUp}
            iconClassName="bg-success-light text-success"
          />
          <MetricCard
            title="Despesas"
            value="R$ 4.580,00"
            change="-3.1% este mês"
            changeType="positive"
            icon={TrendingDown}
            iconClassName="bg-destructive-light text-destructive"
          />
          <MetricCard
            title="Economia"
            value="R$ 3.740,00"
            change="+12.8% este mês"
            changeType="positive"
            icon={PiggyBank}
            iconClassName="bg-warning-light text-warning"
          />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <SpendingChart />
          <CategoryChart />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <TransactionsList />
          <BudgetOverview />
          <AIInsights financialData={financialData} />
        </div>
      </div>
    </DashboardLayout>
  );
};

export default Index;
